# گزارش علت قطعی مشکل iframe موسیقی

## مبنای بررسی

مبنای کد Android: شاخه `arena/01a0fe97-com-hamyareman-ir` در commit `ac46c74e3d5d495e434409f2af3fa77524df968e`.

مبنای HTML: گزارش واقعی decrypt شده از دو فایل باکتِ یوگا و ورزش در `ci-report/lesson-music-host.md`.

## علت واقعی

دو لایه هم‌زمان مالک هندسه و تعامل iframe موسیقی هستند.

### لایه اول — خود HTML

`HamyaremanBackground.mount` در HTMLِ درس، هنگام `state.opened`، همان iframe را با `style.cssText` از یک قاب عادی 88px به `position:fixed` و کل viewport می‌برد و هم‌زمان `document.body.style.overflow='hidden'` می‌گذارد. روی close همان style و overflow را برمی‌گرداند.

این رفتار در کد واقعی HTML گزارش‌شده از باکت مشاهده شده و حدس نیست.

### لایه دوم — Bridge فعلی Android

`MusicFrameOverlayBridge.kt` همان iframe را دوباره به‌عنوان عنصر popup مدیریت می‌کند: stylesheet با `!important` تزریق می‌کند، روی همان iframe attribute می‌نویسد، کلاس overflow روی `html/body` می‌گذارد و iframe را `focus()` می‌کند.

پس یک عنصر، دو مالک هندسه و لایه دارد: HTML با inline style و Bridge با CSS/DOM اجباری.

نتیجهٔ مستقیم: در لحظهٔ touch/open، iframe از حالت عادی به یک لایهٔ تمام‌صفحهٔ ثابت منتقل می‌شود و هم‌زمان سند والد قفل می‌شود. همین توضیح می‌دهد چرا میزبان دیگر scroll/touch/menu عادی ندارد.

### برای «بشنو و بخواب» یک مشکل دوم و مستقل هم وجود دارد

`BackgroundMusicTileHost` فعلی داخل `Column.verticalScroll(...)` قرار گرفته و هنگام بازشدن ارتفاع همان WebView را با `animateDpAsState(..., 340ms)` از 92dp تا تقریباً کل ارتفاع صفحه تغییر می‌دهد.

بنابراین خود WebView در حالی که touch/open را پردازش می‌کند، 16ms-به-16ms توسط Compose دوباره اندازه‌گیری می‌شود و parent آن نیز عضو scroll container است. این همان جفت شدن نامطلوب WebView + verticalScroll + animated resize است.

پچ این بخش را از ریشه حذف می‌کند: WebView از `verticalScroll` خارج می‌شود، جای 92dp آن در اسکرول با `Spacer` نگه داشته می‌شود و خود WebView در حالت باز به‌صورت overlay بیرون از scroll اندازه‌گیری می‌شود؛ همچنین animation ارتفاع حذف شده است.

## چرا 6–7 ثانیه دیده می‌شود

در کد فعلی، close شدن popup از مسیر state خود HTML انجام می‌شود و host Android بعد از آن دوباره به layout عادی برمی‌گردد. عدد 6–7 ثانیه را نمی‌توان از سورس به‌عنوان یک timeout دقیق 6 یا 7 ثانیه‌ای نسبت داد؛ بنابراین آن عدد را به یک timer مشخص نسبت نمی‌دهم.

آنچه قطعی است این است که تا زمانی که حالت باز/لایه تمام‌صفحه و اندازه‌گیری مجدد برقرار است، میزبان رفتار عادی ندارد؛ پس از برگشت state به closed، style/overflow دوباره آزاد می‌شوند و میزبان برمی‌گردد.

## یک ناسازگاری مهم در APK لینک‌شده

Release `ci-apk` که APK 2.4.4 را ارائه می‌کند، `target_commitish` آن `main` است، نه شاخهٔ `arena/01a0fe97-com-hamyareman-ir`. بنابراین این APK را نمی‌توان بدون تطبیق commit، معادل قطعی build شاخهٔ arena دانست.

## اصلاح انجام‌شده

- Bridge فقط state را گزارش می‌کند؛ هیچ style/attribute/overflow/focus روی صفحهٔ میزبان اعمال نمی‌کند.
- Tile WebView از `verticalScroll` خارج می‌شود.
- resize انیمیشنی WebView حذف می‌شود.
- هندسهٔ popup در هر صفحه فقط یک مالک دارد: HTML برای iframe داخلی، و Compose برای جای‌گذاری خود WebView.
