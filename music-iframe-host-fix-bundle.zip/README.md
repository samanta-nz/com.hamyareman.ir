# music iframe host fix

Target branch:
`arena/01a0fe97-com-hamyareman-ir`

Patch:
`music-iframe-host-fix.patch`

What it changes:
1. `MusicFrameOverlayBridge` becomes state-only. It no longer injects CSS, writes iframe attributes, changes `html/body` overflow, or calls `iframe.focus()`. The HTML player remains the only owner of iframe geometry.
2. `BackgroundMusicTileHost` stops animating the WebView height. Height changes are immediate.
3. `SleepNightScreen` moves the tile WebView out of `verticalScroll` and keeps a 92dp placeholder in the scroll content. When opened, the same WebView is a native Compose overlay instead of a WebView whose parent is being re-laid-out by a scroll container.

Apply with:
`git checkout arena/01a0fe97-com-hamyareman-ir`
`git apply music-iframe-host-fix.patch`

Then validate:
`./gradlew :hamyar-app:compileP09DebugKotlin`
